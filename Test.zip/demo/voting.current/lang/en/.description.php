<?
$MESS ['VOTE_CURRENT_NAME'] = "Current poll";
$MESS ['VOTE_CURRENT_DESCRIPTION'] = "Displays form or results for current vote";
$MESS ['VOTING_SERVICE'] = "Polls and voting";
?>