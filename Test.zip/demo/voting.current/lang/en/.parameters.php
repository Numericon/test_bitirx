<?
$MESS["VOTE_VOTE_ID"] = "Poll ID";
$MESS["VOTE_CHANNEL_SID"] = "Poll channel";
$MESS["VOTE_SELECT_DEFAULT"] = "select poll channel";
$MESS["F_VOTE_UNIQUE_SESSION"] = "within the same session";
$MESS["F_VOTE_UNIQUE_COOKIE_ONLY"] = "with the same cookie";
$MESS["F_VOTE_UNIQUE_IP_ONLY"] = "on per IP basis";
$MESS["F_VOTE_UNIQUE_USER_ID_ONLY"] = "on per user ID basis";
$MESS["F_VOTE_UNIQUE_IP_DELAY"] = "Deny repeated votes from the same IP for";
$MESS["F_VOTE_UNIQUE"] = "Deny repeated votes";
$MESS["F_VOTE_SECONDS"] = "seconds";
$MESS["F_VOTE_MINUTES"] = "minutes";
$MESS["F_VOTE_HOURS"] = "hours";
$MESS["F_VOTE_DAYS"] = "days";
$MESS["VOTE_ALL_RESULTS"] = "Show response options for the \"Text\" and \"Textarea\" fields";
?>