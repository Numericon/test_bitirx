<?
$MESS["VOTE_MODULE_IS_NOT_INSTALLED"] = "Polls module is not installed.";
?>