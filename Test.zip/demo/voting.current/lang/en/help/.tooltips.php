<?
$MESS["CHANNEL_SID_TIP"] = "Poll Group";
$MESS["CACHE_TYPE_TIP"] = "Cache Type";
$MESS["CACHE_TIME_TIP"] = "Cache Lifetime (sec.)";
?>