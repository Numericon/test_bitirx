<?
$MESS ['VOTE_MAIN_PAGE_GREEN_NAME'] = "Template for the main page (green)";
$MESS ['VOTE_MAIN_PAGE_GREEN_DESC'] = "Template for the main page (green)";
?>