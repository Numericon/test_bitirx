<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("VOTE_DOT_DEFAULT_NAME"),
	"DESCRIPTION" => GetMessage("VOTE_DOT_DEFAULT_DESC"),
);
?>