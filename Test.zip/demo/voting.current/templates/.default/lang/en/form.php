<?
$MESS ['VOTE_BACK'] = "Poll";
?>