<?
$MESS["VOTE_MAIN_PAGE_BLUE_NAME"] = "Simple Template";
$MESS["VOTE_MAIN_PAGE_BLUE_DESC"] = "Simple Template";
?>