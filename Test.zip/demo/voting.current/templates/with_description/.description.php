<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$arTemplateDescription = array(
	"NAME" => GetMessage("VOTE_WITH_DESCRIPTION_NAME"),
	"DESCRIPTION" => GetMessage("VOTE_WITH_DESCRIPTION_DESC")
);
?>