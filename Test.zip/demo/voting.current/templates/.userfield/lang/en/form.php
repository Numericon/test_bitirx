<?
$MESS["VOTE_SUBMIT_BUTTON"] = "Vote";
$MESS["VOTE_RESULTS"] = "Result";
?>