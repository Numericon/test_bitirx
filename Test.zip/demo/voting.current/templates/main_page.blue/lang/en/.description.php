<?
$MESS ['VOTE_MAIN_PAGE_BLUE_NAME'] = "Template for the main page (blue)";
$MESS ['VOTE_MAIN_PAGE_BLUE_DESC'] = "Template for the main page (blue)";
?>