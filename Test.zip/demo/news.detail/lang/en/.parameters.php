<?
$MESS ['T_IBLOCK_DESC_ASC'] = "Ascending";
$MESS ['T_IBLOCK_DESC_DESC'] = "Descending";
$MESS ['T_IBLOCK_DESC_FID'] = "ID";
$MESS ['T_IBLOCK_DESC_FNAME'] = "Name";
$MESS ['T_IBLOCK_DESC_FACT'] = "Activation date";
$MESS ['T_IBLOCK_DESC_FSORT'] = "Sorting";
$MESS ['T_IBLOCK_DESC_FTSAMP'] = "Date of last change";
$MESS ['T_IBLOCK_DESC_LIST_ID'] = "Information block code";
$MESS ['T_IBLOCK_DESC_LIST_TYPE'] = "Type of information block (used for verification only)";
$MESS ['T_IBLOCK_DESC_DETAIL_ID'] = "News ID";
$MESS ['T_IBLOCK_DESC_LIST_PAGE_URL'] = "List page URL (from information block settings by default)";
$MESS ['T_IBLOCK_DESC_INCLUDE_IBLOCK_INTO_CHAIN'] = "Include information block into navigation chain";
$MESS ['T_IBLOCK_PROPERTY'] = "Properties";
$MESS ['T_IBLOCK_DESC_NEWS_PANEL'] = "Display panel buttons for this component";
$MESS ['T_IBLOCK_DESC_KEYWORDS'] = "Set page keywords from property";
$MESS ['T_IBLOCK_DESC_DESCRIPTION'] = "Set page description from property";
$MESS ['IBLOCK_FIELD'] = "Fields";
$MESS ['T_IBLOCK_DESC_ACTIVE_DATE_FORMAT'] = "Date display format";
$MESS ['T_IBLOCK_DESC_USE_PERMISSIONS'] = "Use additional access restriction";
$MESS ['T_IBLOCK_DESC_GROUP_PERMISSIONS'] = "User groups allowed to view detailed description";
$MESS ['T_IBLOCK_DESC_PAGER_PAGE'] = "Page";
$MESS ['T_IBLOCK_DESC_ADD_SECTIONS_CHAIN'] = "Add Section name to breadcrumb navigation";
?>