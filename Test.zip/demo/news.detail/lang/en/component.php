<?
$MESS ['T_NEWS_DETAIL_NF'] = "Element is not found";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
$MESS ['T_NEWS_DETAIL_PERM_DEN'] = "You do not have enough permissions to view the full text";
?>