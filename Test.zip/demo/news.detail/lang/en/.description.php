<?
$MESS ['MY_NEWS_DETAIL_NAME'] = "News details";
$MESS ['MY_NEWS_DETAIL_DESC'] = "Shows the news details";
$MESS ['MY_COMPONENTS'] = "My components";
$MESS ['MY_NEWS'] = "News";
?>