<?
$MESS ['T_IBLOCK_DESC_ASC'] = "aufsteigend";
$MESS ['T_IBLOCK_DESC_DESC'] = "absteigend";
$MESS ['T_IBLOCK_DESC_FID'] = "ID";
$MESS ['T_IBLOCK_DESC_FNAME'] = "Name";
$MESS ['T_IBLOCK_DESC_FACT'] = "Aktivierungsdatum";
$MESS ['T_IBLOCK_DESC_FSORT'] = "Sortierung";
$MESS ['T_IBLOCK_DESC_FTSAMP'] = "Datum der letzten �nderung";
$MESS ['T_IBLOCK_DESC_LIST_ID'] = "Informationsblock Code";
$MESS ['T_IBLOCK_DESC_LIST_TYPE'] = "Typ des Informationsblock (wird nur zum Vergleich ben�tigt)";
$MESS ['T_IBLOCK_DESC_DETAIL_ID'] = "News ID";
$MESS ['T_IBLOCK_DESC_LIST_PAGE_URL'] = "Listenseite URL (aus den Informationsblock Einstellungen gem. Standard)";
$MESS ['T_IBLOCK_DESC_INCLUDE_IBLOCK_INTO_CHAIN'] = "Integriere Informationsblock in Navigationskette";
$MESS ['T_IBLOCK_PROPERTY'] = "Eigenschaften";
$MESS ['T_IBLOCK_DESC_NEWS_PANEL'] = "Schaltfl�chen f�r diese Komponente anzeigen";
$MESS ['T_IBLOCK_DESC_KEYWORDS'] = "Setze Seiten-Schl�sselw�rter aus Eigenschaften";
$MESS ['T_IBLOCK_DESC_DESCRIPTION'] = "Setze Seitenbeschreibung aus Eigenschaften";
$MESS ['IBLOCK_FIELD'] = "Felder";
$MESS ['T_IBLOCK_DESC_ACTIVE_DATE_FORMAT'] = "Datum Anzeigeformat";
$MESS ['T_IBLOCK_DESC_USE_PERMISSIONS'] = "Benutzen Sie eine zus�tzliche Zugriffsbeschr�nkung";
$MESS ['T_IBLOCK_DESC_GROUP_PERMISSIONS'] = "Benutzergruppen welche die Detailbeschreibung ansehen k�nnen";
$MESS ['T_IBLOCK_DESC_PAGER_PAGE'] = "Seite";
$MESS ['T_IBLOCK_DESC_ADD_SECTIONS_CHAIN'] = "Bereich zu Breadcrump-Navigation hinzuf�gen";
?>