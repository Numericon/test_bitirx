<?
$MESS ['MY_NEWS_DETAIL_NAME'] = "Newsdetails";
$MESS ['MY_NEWS_DETAIL_DESC'] = "Zeigt die Newsdetails an";
$MESS ['MY_COMPONENTS'] = "Meine Komponenten";
$MESS ['MY_NEWS'] = "News";
?>