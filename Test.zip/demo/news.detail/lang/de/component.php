<?
$MESS ['T_NEWS_DETAIL_NF'] = "Element nicht gefunden";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Informationsblock-Modul nicht installiert";
$MESS ['T_NEWS_DETAIL_PERM_DEN'] = "Sie haben nicht genug Rechte den gesamten Text anzusehen";
?>