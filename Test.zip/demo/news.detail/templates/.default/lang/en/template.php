<?
$MESS ['RETURN_TO_LIST'] = "Back to the list";
?>