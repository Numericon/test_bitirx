<?
$MESS ['RETURN_TO_LIST'] = "Zur�ck zur Liste";
?>