<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Elementtitel anzeigen";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Elementtitel anzeigen";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Element-Vorschaubild anzeigen";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Element-Vorschautext anzeigen";
?>