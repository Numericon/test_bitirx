<?
$MESS ['IBLOCK_DETAIL_URL'] = "URL of the page with the detail contents";
$MESS ['T_IBLOCK_DESC_ASC'] = "Ascending";
$MESS ['T_IBLOCK_DESC_DESC'] = "Descending";
$MESS ['T_IBLOCK_DESC_FID'] = "ID";
$MESS ['T_IBLOCK_DESC_FNAME'] = "Name";
$MESS ['T_IBLOCK_DESC_FACT'] = "Activation date";
$MESS ['T_IBLOCK_DESC_FSORT'] = "Sorting";
$MESS ['T_IBLOCK_DESC_FTSAMP'] = "Date of last change";
$MESS ['T_IBLOCK_DESC_IBORD1'] = "Field for the news first sorting pass";
$MESS ['T_IBLOCK_DESC_IBBY1'] = "Direction for the news first sorting pass";
$MESS ['T_IBLOCK_DESC_IBORD2'] = "Field for the news second sorting pass";
$MESS ['T_IBLOCK_DESC_IBBY2'] = "Direction for the news second sorting pass";
$MESS ['T_IBLOCK_DESC_LIST_ID'] = "Information block code";
$MESS ['T_IBLOCK_DESC_LIST_TYPE'] = "Type of information block";
$MESS ['T_IBLOCK_DESC_LIST_CONT'] = "News per page";
$MESS ['T_IBLOCK_DESC_ACTIVE_DATE_FORMAT'] = "Date display format";
?>