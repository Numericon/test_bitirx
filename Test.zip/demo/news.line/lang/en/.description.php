<?
$MESS ['MY_NEWS_LINE_NAME'] = "Articles and news feed";
$MESS ['MY_NEWS_LINE_DESC'] = "List of articles and news with the date and title";
$MESS ['MY_COMPONENTS'] = "My components";
$MESS ['MY_NEWS'] = "News";
?>