<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Informationsblock-Modul nicht installiert";
?>