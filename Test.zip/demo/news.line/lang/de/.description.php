<?
$MESS ['MY_NEWS_LINE_NAME'] = "Artikel und RSS Feeds";
$MESS ['MY_NEWS_LINE_DESC'] = "Liste der Artikel und News mit Datum und Titel";
$MESS ['MY_COMPONENTS'] = "Meine Komponente";
$MESS ['MY_NEWS'] = "News";
?>