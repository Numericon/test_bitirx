<?
$MESS ['IBLOCK_DETAIL_URL'] = "URL of the page with the detail contents";
$MESS ['T_IBLOCK_DESC_ASC'] = "aufsteigend";
$MESS ['T_IBLOCK_DESC_DESC'] = "absteigend";
$MESS ['T_IBLOCK_DESC_FID'] = "ID";
$MESS ['T_IBLOCK_DESC_FNAME'] = "Name";
$MESS ['T_IBLOCK_DESC_FACT'] = "Aktivierungsdatum";
$MESS ['T_IBLOCK_DESC_FSORT'] = "Sortierung";
$MESS ['T_IBLOCK_DESC_FTSAMP'] = "Datum der letzten �nderung";
$MESS ['T_IBLOCK_DESC_IBORD1'] = "Feld f�r ersten Sortierdurchgang in News";
$MESS ['T_IBLOCK_DESC_IBBY1'] = "Sortierrichtung f�r ersten Sortierdurchgang in News";
$MESS ['T_IBLOCK_DESC_IBORD2'] = "Feld f�r zweiten Sortierdurchgang in News";
$MESS ['T_IBLOCK_DESC_IBBY2'] = "Sortierrichtung f�r zweiten Sortierdurchgang in News";
$MESS ['T_IBLOCK_DESC_LIST_ID'] = "Informationsblock Code";
$MESS ['T_IBLOCK_DESC_LIST_TYPE'] = "Informationsblocktyp";
$MESS ['T_IBLOCK_DESC_LIST_CONT'] = "News pro Seite";
$MESS ['T_IBLOCK_DESC_ACTIVE_DATE_FORMAT'] = "Datum Anzeigeformat";
?>