<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display element date";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display element preview picture";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display element preview text";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Show Social Network Bookmarks Bar";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Social Network Bookmarks Template";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Use Social Networks And Bookmarks";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "bit.ly Login";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "bit.ly Key";
$MESS["TP_BN_LIST_USE_SHARE"] = "Show share toolbar in list";
$MESS["TP_BN_MEDIA_PROPERTY"] = "Media property";
$MESS["TP_BN_SLIDER_PROPERTY"] = "Property containing slider images";
$MESS["TP_BN_THEME_SITE"] = "Use site theme (for bitrix.eshop)";
$MESS["TP_BN_THEME_BLUE"] = "blue (default theme)";
$MESS["TP_BN_THEME_GREEN"] = "green";
$MESS["TP_BN_THEME_RED"] = "red";
$MESS["TP_BN_THEME_WOOD"] = "wood";
$MESS["TP_BN_THEME_YELLOW"] = "yellow";
$MESS["TP_BN_THEME_BLACK"] = "dark";
$MESS["TP_BN_TEMPLATE_THEME"] = "Color theme";
?>